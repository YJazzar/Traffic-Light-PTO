# Traffic-Light-PTO
iverilog Traffic Light System


To Compile the code, run the following in the same directory as the source files:
    iverilog *.v

To run the code, run the following command:
    vvp a.out

To view the output of the program, look into the file "Final-Ouput.txt"